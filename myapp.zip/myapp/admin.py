from django.contrib import admin
from .models import profile, usermessages, activities
# Register your models here.

admin.site.register(profile)
admin.site.register(usermessages)
admin.site.register(activities)
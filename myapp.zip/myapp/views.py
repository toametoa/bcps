from django.shortcuts import render, redirect
from django.http import HttpResponse
from .forms import UserRegisterForm, UserUpdateForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from myapp.models import profile, activities, usermessages
from myapp.forms import *
from datetime import datetime
from time import gmtime, strftime

import threading
from .mailer import startmailer
from .mailer_spam import startmailer_spam
from .mailfuncs import detrack





# Create your views here.
def index(request):

    return render(request, "index.html")



def register(request):
    if request.method == 'POST':
        form =  UserRegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data.get('username')
            messages.success(request, f'Welcome {username}! Your Account Has Been Created! You Can Log In Now!')
            return redirect('login')
    else:
        form =  UserRegisterForm()

    return render(request, "register.html", {'form': form})


@login_required
def uprofile(request):
    currentuser = request.user
    ison = request.user.profile.ison
    isactive = request.user.profile.isactive
    uconfig = profile.objects.get(User=currentuser).uconfig
    ucont = profile.objects.get(User=currentuser).ucont
    webmails = profile.objects.get(User=currentuser).webmails
    qlistdatas = activities.objects.get(User=currentuser).queuelist
    slistdatas=activities.objects.get(User=currentuser).sentlistlist 
    totalsent = 0
    # ucv = ucont.values()
    # for x in ucv:
    #     totalsent += int(x['mvalue'])
    totalmail= len(ucont)
    
    webm = {'smtp':'gd'}

    
    smaildataset = []
    for key,slistdata in slistdatas.items(): 
        sleadmail = slistdata.get('leadmail')
        contdt = ucont.get(sleadmail) 
        
        update = slistdata.update(contdt) 
        smaildataset = [slistdata] + smaildataset  

        asndmail = slistdata.get('asndmail')
        webmail = webmails.get(asndmail)
        webmail['tsent'] = int(webmail['tsent']) +1

    qmaildataset = []
    for key,qlistdata in qlistdatas.items():
        qtype = qlistdata.get('mailtype') 
        if qtype == 'reply':
            qlistdata.update({'leadmail': key})
            qlistdata.update({'msgno': qlistdata.get('mvalue')})
            qmaildataset = [qlistdata] + qmaildataset 
        else:
            qlistdata.update({'leadmail': key})
            qlistdata.update({'msgno': qlistdata.get('mvalue2')})
            qmaildataset = qmaildataset + [qlistdata]   


 

    context = { 'smaildataset':smaildataset[:40], 'qmaildataset':qmaildataset[:5], "host_con":uconfig['host_con'] , "ison":ison, "totalsent": totalsent, "totalmail": totalmail,
     "momail": uconfig['emaill'], "webmails":webmails, 'ucont':ucont }
    return render(request, 'profile.html', context)




@login_required
def settings(request):
    currentuser = request.user
    if request.method == 'POST':

        uconfig = profile.objects.get(User=currentuser).uconfig
        #uconfig['smtp'] = request.POST.get('smtp_input', None)
        #uconfig['imap'] = request.POST.get('imap_input', None)
        uconfig['port'] = request.POST.get('port_input', None)
        uconfig['name'] = request.POST.get('name_input', None)
        uconfig['emaill'] = request.POST.get('emaill_input', None)
        uconfig['pass'] = request.POST.get('pass_input', None)
        uconfig['delay'] = request.POST.get('delay_input', None)
        uconfig['nrdelay'] = request.POST.get('nrdelay_input', None)
        profile.objects.filter(User=currentuser).update(uconfig=uconfig)


        context = {"uconfig": uconfig, "fc1":'mail.privatebox.smtp', "fc2":'mail.privetebox.imap', "fc3":uconfig['port'], "fc4":uconfig['name'], "fc5":uconfig['emaill'], "fc6":uconfig['pass'], "fc7":uconfig['delay'], "fc8":uconfig['nrdelay']}

    else:
        uconfig = profile.objects.get(User=currentuser).uconfig
        context = {"uconfig": uconfig, "fc1":'mail.privatebox.smtp', "fc2":'mail.privetebox.imap', "fc3":uconfig['port'], "fc4":uconfig['name'], "fc5":uconfig['emaill'], "fc6":uconfig['pass'], "fc7":uconfig['delay'], "fc8":uconfig['nrdelay']}




    # profile.objects.filter(User=currentuser).update(city='some value')
    # city = profile.objects.get(User=currentuser).ucont
    # city[str(currentuser)] = 4444444444
    # profile.objects.filter(User=currentuser).update(ucont=city)
    # context = {"city": city}
    return render(request, 'settings.html', context)




def webmail(request,wmlarg):
    currentuser = request.user
    webmails = profile.objects.get(User=currentuser).webmails
    if request.method == 'POST':
        smtp = request.POST.get('smtp_input', None)
        port = request.POST.get('port_input', None)
        emaill = request.POST.get('emaill_input', None)
        passs = request.POST.get('pass_input', None)
        gttime = datetime.now()
        addedon = gttime.strftime("%d-%m-%Y")
        if ( smtp != 'smtp' and port != 'port' and emaill != 'email' and passs != 'pass' ):
            webmails[emaill] = {'smtp':smtp, 'port':port, 'passs':passs, 'addedon':addedon, 'tsent':0 }

            profile.objects.filter(User=currentuser).update(webmails=webmails)
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
        else:
            messages.warning(request, f'Failed! Please enter valid ACCESS')
            return redirect('profile')
        
        


        
    else:
        if wmlarg in webmails:
            del webmails[wmlarg]
            profile.objects.filter(User=currentuser).update(webmails=webmails)
            messages.success(request, f'Done! Webmail Deleted!')
            return redirect('profile')
       
    return render(request, 'addwebmail.html')
            

def tracking(request, trid):
    stime = detrack(trid)
    currentuser = request.user
    slistdatas=activities.objects.get(User=currentuser).sentlistlist
    sdataset = slistdatas[stime]
    sdataset['track'] = str(datetime.now())
    print(sdataset)
    activities.objects.filter(User=currentuser).update(sentlistlist=slistdatas)
    
    return render(request, "start.html")

def start(request):
    startmailer()
    return render(request, "start.html")

def startspam(request):
    startmailer_spam()
    return render(request, "start.html")

def stop(request):

    return render(request, "profile.html")

def on(request):
    currentuser = request.user
    isactive = request.user.profile.isactive
    if isactive == True:
        profile.objects.filter(User=currentuser).update(ison=True)
    else:
        messages.warning(request, f'Can Not Start Autoresponder! Account Is Inactive.')


    return redirect('profile')

def off(request):
    currentuser = request.user
    profile.objects.filter(User=currentuser).update(ison=False)
    profile()

    return redirect('profile')







def db(request):

    greeting = Greeting()
    greeting.save()

    greetings = Greeting.objects.all()

    return render(request, "db.html", {"greetings": greetings})


def replymessages(request):
    auser = request.user
    ucontdata=profile.objects.get(User=auser).ucont
    usermessage=usermessages.objects.get(User=auser).template01 

    context = {"usermessages": usermessage }
    return render(request, 'replymessages.html', context)

def templates1(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md1'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm01(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')

        
    else:
        t1uform = TempUpdateForm01(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md1']}
    return render(request, 'updatetemp/templates1.html', context)





def templates2(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md2'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm02(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm02(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md2']}
    return render(request, 'updatetemp/templates2.html', context)





def templates3(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md3'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm03(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm03(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md3']}
    return render(request, 'updatetemp/templates3.html', context)





def templates4(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md4'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm04(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm04(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md4']}
    return render(request, 'updatetemp/templates4.html', context)





def templates5(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md5'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm05(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm05(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md5']}
    return render(request, 'updatetemp/templates5.html', context)





def templates6(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md6'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm06(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm06(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md6']}
    return render(request, 'updatetemp/templates6.html', context)



def templates7(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md7'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm07(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm07(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md7']}
    return render(request, 'updatetemp/templates7.html', context)




def templates8(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md8'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm08(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm08(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md8']}
    return render(request, 'updatetemp/templates8.html', context)




def templates9(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md9'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm09(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm09(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md9']}
    return render(request, 'updatetemp/templates9.html', context)






def templates10(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md10'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm10(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm10(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md10']}
    return render(request, 'updatetemp/templates10.html', context)





def templates11(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md11'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm11(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm11(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md11']}
    return render(request, 'updatetemp/templates11.html', context)




def templates12(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md12'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm12(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm12(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md12']}
    return render(request, 'updatetemp/templates12.html', context)


def templates13(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md13'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm13(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm13(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md13']}
    return render(request, 'updatetemp/templates13.html', context)




def templates14(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md14'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm14(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm14(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md14']}
    return render(request, 'updatetemp/templates14.html', context)



def templates15(request):
    currentuser = request.user
    if request.method == 'POST':
        mdelay = usermessages.objects.get(User=currentuser).messagedelay
        mdelay['md15'] = request.POST.get('mdelay_input', None)
        usermessages.objects.filter(User=currentuser).update(messagedelay=mdelay)
        t1uform = TempUpdateForm15(request.POST,instance=request.user.usermessages)
        if t1uform.is_valid() and t1uform.is_valid():
            t1uform.save()
            messages.success(request, f'Done! Your Account Has Been Updated!')
            return redirect('profile')
    else:
        t1uform = TempUpdateForm15(instance=request.user.usermessages)
        mdelay = usermessages.objects.get(User=currentuser).messagedelay



    context = {"t1uform": t1uform, 'mdelay':mdelay['md15']}
    return render(request, 'updatetemp/templates15.html', context)









from django.contrib.auth.models import User

import imaplib
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from myapp.models import profile, activities, usermessages
from .mailfuncs import getmsgdata, formattime, deltaminutes, entrack
from time import gmtime, strftime
from datetime import datetime





def startmailer_spam():
	allusers= User.objects.all()
	for auser in allusers:
		auserdt = profile.objects.get(User=auser)
		if auserdt.ison == True and auserdt.isactive == True:
			qlistdatas=activities.objects.get(User=auser).queuelist 
			for qlistdata in qlistdatas:
				dataset = qlistdatas.get(qlistdata)
				# calculating current time and sendtime				
				stime = dataset.get('stime')
				fdtime = formattime(stime)
				crtime = datetime.now()
				if   fdtime > crtime  :
					print('waiting')
					continue
				else: 
					print('sending') 


					# getting lead data for sending mail
					try:
						leadmail = qlistdata                              #need
						leadmail_mid = dataset.get('leadmail_mid')        #need
						firstname = dataset.get('firstname')
						mvalue = dataset.get('mvalue')
						mvalue2 = dataset.get('mvalue2')
						asndmail = dataset.get('asndmail')
						mailtype = dataset.get('mailtype')

						# grtting msgno then msg body
						if mailtype == 'followup':
							msgno = int(mvalue2)+10 
							mvalue2 += 1
						elif mailtype == 'reply':
							msgno = mvalue
							mvalue += 1
						# getting dtime(delayTime) and getting formtted msg
						getmsg, dtime = getmsgdata(auser, int(msgno) )        #need    

						# tracking
						tracking = auserdt.uconfig.get('tracking', 0) 
						if tracking == 'yes':
							track = 'Not Opened Yet'
							body = getmsg + entrack(crtime)
						else:
							track = 'Tracking Off'
							body = getmsg
						

						# getting mothermail access's
						modelname = auserdt.uconfig.get('name', 0)
						mailaccess = auserdt.webmails.get(asndmail, 0)
						emailll = asndmail                                  #need  
						smtp = mailaccess.get('smtp')                       #need  
						port = mailaccess.get('port')                       #need   
						passs = mailaccess.get('passs')                     #need   
					except:
						status = 'leadmailprob'
						continue



				
					# sending :):):):):):):)
					try:
						msg = MIMEMultipart()
						msg['From'] = (modelname  + '<' + emailll + '>')
						msg['To'] = leadmail
						msg['Subject'] = ""
						msg.add_header('In-Reply-To', leadmail_mid)
						msg.add_header('References', leadmail_mid)
						msg.attach(MIMEText(body, 'html'))

						server = smtplib.SMTP(smtp, port)
						server.starttls()
						server.login(emailll, passs)

						text = msg.as_string()
						server.sendmail(emailll, leadmail, text)
						server.quit()
						status = 'sent'
					except:
						status = 'webmailprob'
						continue

					# sent done,, now signal followup .......................
					if mvalue2  < 6: 
						# calculating exact sending time by dtime
						getmsg, dtime = getmsgdata(auser, int(mvalue2)+10 ) 
						newstime = ( crtime + deltaminutes(dtime))

						# saveing final lead dataset ucont
						ldataset=profile.objects.get(User=auser).ucont
						ldataset[leadmail] = { 'leadmail_mid':leadmail_mid, 'firstname':firstname, 
						'stime':str(newstime), 'mvalue':mvalue, 'mvalue2':mvalue2, 'asndmail':asndmail } 
						profile.objects.filter(User=auser).update(ucont=ldataset)

				        #  new folloup data to queue
						qlistdata=activities.objects.get(User=auser).queuelist
						qlistdata[leadmail] = { 'leadmail_mid':leadmail_mid, 'firstname':firstname, 
						'stime':str(newstime), 'mvalue':mvalue, 'mvalue2':mvalue2, 'asndmail':asndmail, 'mailtype':'followup' }
						activities.objects.filter(User=auser).update(queuelist=qlistdata)

					elif mvalue2  > 5:
						print(str(auser) + '>>> All 5 followup Mails Sent to!' + leadmail+ ' Already!(code:- LLA-TNES-RELIAM-201)', flush=True)
						qlistdata=activities.objects.get(User=auser).queuelist
						del qlistdata[leadmail]
						activities.objects.filter(User=auser).update(queuelist=qlistdata)
					else:
						pass



					if status == 'sent':
						slistdata=activities.objects.get(User=auser).sentlistlist
						slistdata[str(crtime)] =  { 'leadmail':leadmail, 'senttime':str(crtime),'mailtype':mailtype, 'status':status, 'msgno':msgno, 'track':track }
						activities.objects.filter(User=auser).update(sentlistlist=slistdata)

					elif status == 'webmailprob' or status == 'leadmailprob':
						flistdata=activities.objects.get(User=auser).failedlist
						flistdata[str(crtime)] = { 'leadmail':leadmail, 'mailtype':mailtype, 'status':status, 'msgno':msgno }
						activities.objects.filter(User=auser).update(failedlist=flistdata)
					else:
						pass
					print(crtime)
				


						# # making webmail status ok
						# print(str(auser) + '>>> Email Sent Successfully', flush=True)
						# condta=auserdt.uconfig
						# condta[emailll] = 'ok'
						# profile.objects.filter(User=auser).update(uconfig=condta)
				# # except:
				# 	# pop from qlist and add to error list.......................
					# flistdata=activities.objects.get(User=auser).failedlist
					# flistdata[str(crtime)] = [leadmail,mailtype,'failed']
					# activities.objects.filter(User=auser).update(failedlist=flistdata)


				# 	nqlistdata=activities.objects.get(User=auser).queuelist
				# 	del nqlistdata[leadmail]
				# 	activities.objects.filter(User=auser).update(queuelist=nqlistdata)
				# 	# making webmail status notok
				# 	print(str(auser) + '>>> Please Check Your smtp Settings(error code:- PTMS-RELIAM-402)', flush=True)
				# 	condta=auserdt.uconfig
				# 	condta[emailll] = 'notok'
				# 	profile.objects.filter(User=auser).update(uconfig=condta)
				# # else:
		# 		# 	# pass
		# slistdata=activities.objects.get(User=auser).sentlistlist
		# slistdata[str(crtime)] =  { 'leadmail':leadmail, 'firstname':firstname,
		# 'stime':str(stime), 'mvalue':mvalue, 'mailtype':mailtype , 'asndmail':asndmail }
		# activities.objects.filter(User=auser).update(sentlistlist=slistdata)
		


					# except:
						# print('Sending Failed. problem with ' + qlistdata)
						# pop from qlist and add to error faildlist..................
						# flistdata=activities.objects.get(User=auser).failedlist
						# flistdata[str(crtime)] = [leadmail,mailtype,'error']
						# activities.objects.filter(User=auser).update(failedlist=flistdata)


						# nqlistdata=activities.objects.get(User=auser).queuelist
						# del nqlistdata[leadmail]
						# activities.objects.filter(User=auser).update(queuelist=nqlistdata)

						# continue
					
					# try:
			


			# 	except:
			# 		pass
			# 	print(str(auser) + '>>> Mail No.' + str(mvalue) + ' Sent To:'+ leadmail, flush=True )
			# except:
			# 	print(str(auser) + '>>> OPPS! Email Sending Failed!(error code:- ROF-POOL-RELIAM-402)', flush=True)
			# 	pass








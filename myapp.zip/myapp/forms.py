from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import profile, usermessages

class UserRegisterForm(UserCreationForm):
	email = forms.EmailField()

 
	class Meta:
		model = User
		fields = ['username', 'email', 'password1', 'password2']


class UserUpdateForm(forms.ModelForm):
	"""docstring for UserUpdateForm"""
	email = forms.EmailField()


	class Meta:
		model = User
		fields = ['username', 'email']



class TempUpdateForm01(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template01": " "}
		fields = ['template01']



class TempUpdateForm02(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template02": " "}
		fields = ['template02']



class TempUpdateForm03(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template03": " "}
		fields = ['template03']



class TempUpdateForm04(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template04": " "}
		fields = ['template04']



class TempUpdateForm05(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template05": " "}
		fields = ['template05']



class TempUpdateForm06(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template06": " "}
		fields = ['template06']



class TempUpdateForm07(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template07": " "}
		fields = ['template07']



class TempUpdateForm08(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template08": " "}
		fields = ['template08']



class TempUpdateForm09(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template09": " "}
		fields = ['template09']



class TempUpdateForm10(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"template10": " "}
		fields = ['template10']



class TempUpdateForm11(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"followup01": " "}
		fields = ['followup01']



class TempUpdateForm12(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"followup02": " "}
		fields = ['followup02']



class TempUpdateForm13(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"followup03": " "}
		fields = ['followup03']



class TempUpdateForm14(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"followup04": " "}
		fields = ['followup04']



class TempUpdateForm15(forms.ModelForm):
	
	class Meta:
		model = usermessages
		labels = {"followup05": " "}
		fields = ['followup05']


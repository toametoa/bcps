from django.urls import path, include
from . import views
from django.contrib.auth import views as auth_views



urlpatterns = [
    path("", views.index, name="index"),
    path("webmail/<wmlarg>/", views.webmail, name="webmail"),
    path("register/", views.register, name="register"),
    path("dashboard/", views.uprofile, name="profile"),
    path("settings/", views.settings, name="settings"),
    path("login/", auth_views.LoginView.as_view(template_name='login.html'), name="login"),
    path("logout/", auth_views.LogoutView.as_view(template_name='index.html'), name="logout"),
    path("tracking/<trid>/", views.tracking, name="tracking"),
    path("start/", views.start, name="start"),
    path("startspam/", views.startspam, name="startspam"),
    path("stop/", views.stop, name="stop"),
    path("on/", views.on, name="on"),
    path("off/", views.off, name="off"),
    path("replymessages/", views.replymessages, name="replymessages"),
    path("templates1/", views.templates1, name="templates1"),
    path("templates2/", views.templates2, name="templates2"),
    path("templates3/", views.templates3, name="templates3"),
    path("templates4/", views.templates4, name="templates4"),
    path("templates5/", views.templates5, name="templates5"),
    path("templates6/", views.templates6, name="templates6"),
    path("templates7/", views.templates7, name="templates7"),
    path("templates8/", views.templates8, name="templates8"),
    path("templates9/", views.templates9, name="templates9"),
    path("templates10/", views.templates10, name="templates10"),
    path("templates11/", views.templates11, name="templates11"),
    path("templates12/", views.templates12, name="templates12"),
    path("templates13/", views.templates13, name="templates13"),
    path("templates14/", views.templates14, name="templates14"),
    path("templates15/", views.templates15, name="templates15"),

]
from datetime import datetime, timedelta
from myapp.models import profile, activities, usermessages
import random

def formattime(strtime):
	return datetime.strptime(strtime, "%Y-%m-%d %H:%M:%S.%f")

def deltaminutes(time):
	return timedelta(minutes=time)

def entrack(crtime):
	dttime = datetime.strptime(crtime, "%Y-%m-%d %H:%M:%S.%f")
	trid = dttime.strftime("%Y-%m-%d%H:%M:%S.%f")
	trcode = '<img alt="" src="http://35.173.69.207/tracking/'+trid+'" style="height:1px; width:1px" />'
	return trcode

def detrack(trid):
	dttime = datetime.strptime(trid, "%Y-%m-%d%H:%M:%S.%f")
	tridtime = dttime.strftime("%Y-%m-%d %H:%M:%S.%f")
	return tridtime


def getmsgdata(auser, msgno):
	mddata = usermessages.objects.get(User=auser).messagedelay
	msgdata = usermessages.objects.get(User=auser)
	if msgno == 1:
		getmsg = msgdata.template01
		dtime = int(mddata['md1'])
	elif msgno == 2:
		getmsg = msgdata.template02
		dtime = int(mddata['md2'])
	elif msgno == 3:
		getmsg = msgdata.template03
		dtime = int(mddata['md3'])
	elif msgno == 4:
		getmsg = msgdata.template04
		dtime = int(mddata['md4'])
	elif msgno == 5:
		getmsg = msgdata.template05
		dtime = int(mddata['md5'])
	elif msgno == 6:
		getmsg = msgdata.template06
		dtime = int(mddata['md6'])
	elif msgno == 7:
		getmsg = msgdata.template07
		dtime = int(mddata['md7'])
	elif msgno == 8:
		getmsg = msgdata.template08
		dtime = int(mddata['md8'])
	elif msgno == 9:
		getmsg = msgdata.template09
		dtime = int(mddata['md9'])
	elif msgno == 10:
		getmsg = msgdata.template10
		dtime = int(mddata['md10'])
	elif msgno == 11:
		getmsg = msgdata.followup01
		dtime = int(mddata['md11'])
	elif msgno == 12:
		getmsg = msgdata.followup02
		dtime = int(mddata['md12'])
	elif msgno == 13:
		getmsg = msgdata.followup03
		dtime = int(mddata['md13'])
	elif msgno == 14:
		getmsg = msgdata.followup04
		dtime = int(mddata['md14'])
	elif msgno == 15:
		getmsg = msgdata.followup05
		dtime = int(mddata['md15'])

	return getmsg, dtime




def mailproccesor(auser, leadmail , leadmail_mid , firstname , msgtime):
	# get a random webmail
	webmails = profile.objects.get(User=auser).webmails
	randmail = random.choice(list(webmails.keys()))

    # get or assain mvalue and asnd mail
	msgcount = profile.objects.get(User=auser).ucont
	kvalue = msgcount.get(leadmail, 0)
	if kvalue == 0:
		mvalue = 1
		mvalue2 = 1
		asndmail = randmail
	else:
		mvalue = kvalue.get('mvalue', 1)
		mvalue2 = kvalue.get('mvalue2', 1)
		asndmail = kvalue.get('asndmail', 0)

	checkasndmail = webmails.get(asndmail, 0)
	if checkasndmail == 0:
		asndmail = randmail
	else:
		pass
	
	

      # getting delay time by mvalue
	if mvalue < 11:
		getmsg, dtime = getmsgdata(auser, int(mvalue) ) 
        # calculating exact sending time by dtime
		stime = ( msgtime + deltaminutes(dtime))

        # saveing final lead dataset
		ldataset=profile.objects.get(User=auser).ucont
		ldataset[leadmail] = { 'leadmail_mid':leadmail_mid, 'firstname':firstname, 
		'stime':str(stime), 'mvalue':mvalue, 'mvalue2':mvalue2, 'asndmail':asndmail } 
		profile.objects.filter(User=auser).update(ucont=ldataset)

        # sending mail and sending time data to queue
		qlistdata=activities.objects.get(User=auser).queuelist
		qlistdata[leadmail] = { 'leadmail_mid':leadmail_mid, 'firstname':firstname, 
		'stime':str(stime), 'mvalue':mvalue, 'mvalue2':mvalue2, 'asndmail':asndmail, 'mailtype':'reply' }
		activities.objects.filter(User=auser).update(queuelist=qlistdata)
	else:
		print(str(auser) + '>>> All 10 Mails Sent to!' + leadmail+ ' Already!(code:- LLA-TNES-RELIAM-201)', flush=True)
		pass

from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from jsonfield import JSONField
from ckeditor.fields import RichTextField

class  profile(models.Model):
    User = models.OneToOneField(User, on_delete=models.CASCADE)
    isactive = models.BooleanField(default=False)
    ison = models.BooleanField(default=False)
    uconfig = JSONField(default={ "smtp":"SMTP Is Empty!", "imap":"IMAP Is Empty!", "port":"Port Is Empty!", "emaill":"Email Is Empty!", "pass":"Password Is Empty!", "name":"Name Is Empty!", "host_con":"not ok" },blank=True, null=False)
    webmails = JSONField(default={ },blank=True, null=False)
    ucont = JSONField(default={},blank=True, null=False)

    def __str__(self):
    	return str(self.User)

def set_profile(sender, **kwargs):
	if kwargs['created']:
		user_profile = profile.objects.create(User=kwargs['instance'])

post_save.connect(set_profile, sender=User)




class  activities(models.Model):
    User = models.OneToOneField(User, on_delete=models.CASCADE,  default='')
    queuelist = JSONField(default={ },blank=True, null=False)
    sentlistlist = JSONField(default={ },blank=True, null=False)
    failedlist = JSONField(default={ },blank=True, null=False)
    
    def __str__(self):
        return str(self.User)

def set_activities(sender, **kwargs):
    if kwargs['created']:
        user_profile = activities.objects.create(User=kwargs['instance'])

post_save.connect(set_activities, sender=User)




class  usermessages(models.Model):
    User = models.OneToOneField(User, on_delete=models.CASCADE, default='')
    messagedelay = JSONField(default={ "md1":"6", "md2":"6", "md3":"6", "md4":"6", "md5":"6", "md6":"6", "md7":"6", "md8":"6", "md9":"6", "md10":"6", "md11":"2", "md12":"2", "md13":"2", "md14":"2", "md15":"2", },blank=True, null=False)
    template01 = RichTextField(default='Template 01 Is Empty!',blank=True, null=False)
    template02 = RichTextField(default='Template 02 Is Empty!',blank=True, null=False)
    template03 = RichTextField(default='Template 03 Is Empty!',blank=True, null=False)
    template04 = RichTextField(default='Template 04 Is Empty!',blank=True, null=False)
    template05 = RichTextField(default='Template 05 Is Empty!',blank=True, null=False)
    template06 = RichTextField(default='Template 06 Is Empty!',blank=True, null=False)
    template07 = RichTextField(default='Template 07 Is Empty!',blank=True, null=False)
    template08 = RichTextField(default='Template 08 Is Empty!',blank=True, null=False)
    template09 = RichTextField(default='Template 09 Is Empty!',blank=True, null=False)
    template10 = RichTextField(default='Template 10 Is Empty!',blank=True, null=False)
    followup01 = RichTextField(default='Follow Up Template 01 Is Empty!',blank=True, null=False)
    followup02 = RichTextField(default='Follow Up Template 02 Is Empty!',blank=True, null=False)
    followup03 = RichTextField(default='Follow Up Template 03 Is Empty!',blank=True, null=False)
    followup04 = RichTextField(default='Follow Up Template 04 Is Empty!',blank=True, null=False)
    followup05 = RichTextField(default='Follow Up Template 05  Is Empty!',blank=True, null=False)

    def __str__(self):
        return str(self.User)


def set_usermessages(sender, **kwargs):
    if kwargs['created']:
        user_profile = usermessages.objects.create(User=kwargs['instance'])

post_save.connect(set_usermessages, sender=User)




